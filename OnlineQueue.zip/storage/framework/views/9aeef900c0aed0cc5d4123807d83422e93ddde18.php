

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Tabel Berkas
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Table Berkas</a></li>
    </ol>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Table Berkas Pengguna </h3>
                    <br>
                    <h3 class="box-title">Total Berkas Baru Hari ini : <?php echo e($newBerkas); ?> </h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIK</th>
                        <th>Status Berkas</th>
                        <th>Catatan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $row->antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($waw->status_antrian == 3): ?>
                            <tr>
                                <td><?php echo e($waw->nama); ?></td>
                                <td><?php echo e($waw->nik); ?></td>
                                <?php $__currentLoopData = $waw->userDoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($usr->status_berkas == 0): ?>
                                    <td><b style = "color : blue ">Berkas Di Proses</b> </td>
                                    <?php elseif($usr->status_berkas == 1): ?>
                                    <td> <b style = "color : green "> Berkas Di Terima </b></td>
                                    <?php elseif($usr->status_berkas == 2): ?>
                                    <td> <b style = "color : red "> Berkas Di Tolak </b></td>
                                    <?php endif; ?>
                                    <td><?php echo e($usr->note); ?></td>
                                
                                    <td>
                                        <form action="<?php echo e(route('kecamatan.documents.edit', $usr->id)); ?>" method="post" class="form-horizontal">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('GET'); ?>
                                            <button type="submit" class="btn btn-success btn-rounded">Update Status Berkas</button>
                                        </form>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/kec_berkas/index.blade.php ENDPATH**/ ?>