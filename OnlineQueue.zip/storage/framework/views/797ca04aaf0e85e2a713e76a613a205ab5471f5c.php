<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('adminlte')); ?>/dist/img/avatar04.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
          <p><?php echo e(Auth::user()->role->role); ?></p>
        </div>
      </div>
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <?php if(Auth::user()->role_id == 1): ?>
        <!-- <li class="header">MASTER DATA</li> -->
        <li><a href="<?php echo e(route('admin.opds.index')); ?>"><i class="fa fa-building"></i> <span>Opd</span></a></li>
        <li><a href="<?php echo e(route('admin.akuns.index')); ?>"><i class="fa fa-users"></i> <span>Akun Dinas</span></a></li>
        <li><a href="<?php echo e(route('admin.uptsAcc.index')); ?>"><i class="fa fa-users"></i> <span>Akun UPT</span></a></li>
        <li><a href="<?php echo e(route('admin.upts.index')); ?>"><i class="fa fa-building"></i> <span>UPT</span></a></li>
        <li><a href="<?php echo e(route('admin.a_kecamatans.index')); ?>"><i class="fa fa-users"></i> <span>Akun Kecamatan</span></a></li>
        <li><a href="<?php echo e(route('admin.a_kelurahans.index')); ?>"><i class="fa fa-users"></i> <span>Akun Kelurahan</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 2): ?>
        <li><a href="<?php echo e(route('dinas.dashboard.index')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li><a href="<?php echo e(route('dinas.layanans.index')); ?>"><i class="fa fa-file"></i> <span>Layanan</span></a></li>
        <li><a href="<?php echo e(route('dinas.lokets.index')); ?>"><i class="fa fa-file"></i> <span>Loket</span></a></li>
        <li><a href="<?php echo e(route('dinas.offlines.index')); ?>" target="_blank"><i class="fa fa-registered"></i> <span>Register offline</span></a></li>
        <li><a href="<?php echo e(route('dinas.documents.index')); ?>"><i class="fa fa-file-text-o"></i> <span>Berkas Kecamatan/UPT</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 3): ?>
        <li><a href="<?php echo e(route('loket.antrians.index')); ?>"><i class="fa fa-file"></i> <span>Antrian</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 4): ?>
        <li><a href="<?php echo e(route('kecamatan.dashboard.index')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li><a href="<?php echo e(route('kecamatan.a_kelurahans.index')); ?>"><i class="fa fa-users"></i> <span>Akun Kelurahan</span></a></li>
        <li><a href="<?php echo e(route('kecamatan.lokets.index')); ?>"><i class="fa fa-file"></i> <span>Loket</span></a></li>
        <li><a href="<?php echo e(route('kecamatan.documents.index')); ?>"><i class="fa fa-file-text-o"></i> <span>Berkas</span></a></li>
        <li><a href="<?php echo e(route('kecamatan.berkasTercetak')); ?>"><i class="fa fa-file-text"></i> <span>Berkas Tercetak</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <li><a href="<?php echo e(route('kecamatan.offlines.index')); ?>" target="_blank"><i class="fa fa-registered"></i> <span>Register offline</span></a></li>
        <?php elseif(Auth::user()->role_id == 5): ?>
        <li><a href="<?php echo e(route('loketKecamatan.antrians.index')); ?>"><i class="fa fa-file"></i> <span>Antrian</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 6): ?>
        <li><a href="<?php echo e(route('kelurahan.kelurahanBerkas')); ?>"><i class="fa fa-file-text"></i> <span>Berkas Tercetak</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 7): ?>
        <li><a href="<?php echo e(route('upt.antrians.index')); ?>"><i class="fa fa-file"></i> <span>Antrian</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <?php elseif(Auth::user()->role_id == 8): ?>
        <li><a href="<?php echo e(route('adminUpt.dashboard.index')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li><a href="<?php echo e(route('adminUpt.lokets.index')); ?>"><i class="fa fa-file"></i> <span>Loket</span></a></li>
        <li><a href="<?php echo e(route('adminUpt.documents.index')); ?>"><i class="fa fa-file-text-o"></i> <span>Berkas</span></a></li>
        <li><a href="<?php echo e(route('adminUpt.berkasTercetak')); ?>"><i class="fa fa-file-text"></i> <span>Berkas Tercetak</span></a></li>
        <li><a href="<?php echo e(route('laporan')); ?>"><i class="fa fa-file-text-o"></i> <span>Laporan Berkas</span></a></li>
        <li><a href="<?php echo e(route('adminUpt.offlines.index')); ?>" target="_blank"><i class="fa fa-registered"></i> <span>Register offline</span></a></li>
        <?php endif; ?>
        
        
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>