



<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1 class="box-title">
        Tabel Loket
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Table Loket</a></li>
    </ol>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if(Auth::user()->role_id == 2): ?>
                    <a href="<?php echo e(route('dinas.lokets.create')); ?>" class="btn btn-rounded btn-danger">Tambah Loket</a>
                    <a href="<?php echo e(route('dinas.liveAntrian')); ?>" target="_blank" class="btn btn-rounded btn-success">Lihat Semua Antrian</a>
                    <a href="<?php echo e(route('dinas.export')); ?>" class="btn btn-rounded btn-primary">Report/Hari</a>
                    <a href="<?php echo e(route('dinas.exportMonth')); ?>" class="btn btn-rounded btn-primary">Report/Bulan</a>
                    <?php elseif(Auth::user()->role_id == 4): ?>
                    <a href="<?php echo e(route('kecamatan.lokets.create')); ?>" class="btn btn-rounded btn-danger">Tambah Loket</a>
                    <a href="<?php echo e(route('kecamatan.liveAntrian')); ?>" target="_blank" class="btn btn-rounded btn-success">Lihat Semua Antrian</a>
                    <?php endif; ?>
                    
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Nama Petugas</th>
                                <th>Nama Loket</th>
                                <th>Nama Layanan</th>
                                <th>Loket Antrian</th>
                                <th>Antrian Hari Ini</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($row->nama_petugas); ?></td>
                                <td><?php echo e($row->nama_loket); ?></td>
                                <td><?php echo e($row->layanan->nama_layanan); ?></td>
                                <td>
                                    <?php if($row->loket_antrian == 1): ?>
                                    Antrian Online
                                    <?php else: ?>
                                    Antrian Offline
                                    <?php endif; ?>
                                </td>
                                <td><b><?php echo e($row->count_of_today); ?></b></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-default dropdown-toggle"
                                            data-toggle="dropdown">
                                            <span class="caret"></span>
                                            <span class="sr-only">Toggle Dropdown</span>
                                        </button>
                                        
                                        <ul class="dropdown-menu" role="menu">
                                            <?php if(Auth::user()->role_id == 2): ?>
                                            <form action="<?php echo e(route('dinas.lokets.edit', $row->id)); ?>" method="post">
                                            <?php elseif(Auth::user()->role_id == 4): ?>
                                            <form action="<?php echo e(route('kecamatan.lokets.edit', $row->id)); ?>" method="post">
                                            <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('GET'); ?>
                                                <button type="submit" class="btn btn-info btn-rounded">EDIT</button>
                                            </form>
                                            <hr>
                                            <?php if(Auth::user()->role_id == 2): ?>
                                            <form action="<?php echo e(route('dinas.lokets.destroy', $row->id)); ?>" method="post">
                                            <?php elseif(Auth::user()->role_id == 4): ?>
                                            <form action="<?php echo e(route('kecamatan.lokets.destroy', $row->id)); ?>" method="post">
                                            <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-rounded">Delete</button>
                                            </form>

                                        </ul>
                                    </div>
                                       
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                    </table>
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

  

   
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/loket/index.blade.php ENDPATH**/ ?>