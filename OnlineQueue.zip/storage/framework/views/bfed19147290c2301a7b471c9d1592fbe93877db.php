


<style> 
    section {
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    }
</style>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1 class="box-title">
        Antrian
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Table Antrian</a></li>
    </ol>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
            <div class="box-header">
                <h1 class="box-title">
                    Table Antrian per Loket
                </h1>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Nama Petugas</th>
                                <th>Nama Loket</th>
                                <th>Antrian Hari Ini</th>
                                <th>Status Loket</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($row->nama_petugas); ?></td>
                                <td><?php echo e($row->nama_loket); ?></td>
                                <td><b><?php echo e($row->count_of_today); ?></b></td>
                                <td>
                                    <?php if( $row->status_loket == 1 ): ?>
                                        <b style = "color : green ">ONLINE</b>
                                    <?php elseif($row->status_loket == 0 ): ?>
                                        <b style = "color : red">OFFLINE</b>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->count_of_today != 0): ?>
                                        <?php if(Auth::user()->role_id == 3): ?>
                                        <form action="<?php echo e(route('loket.statusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php elseif(Auth::user()->role_id == 5): ?>
                                        <form action="<?php echo e(route('loketKecamatan.statusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php elseif(Auth::user()->role_id == 7): ?>
                                        <form action="<?php echo e(route('upt.statusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php endif; ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($row->id); ?>" name="idLoket">
                                            <button type="submit" class="btn btn-rounded btn-success">Mulai Antrian</button>
                                        </form>
                                        <hr>
                                    <?php endif; ?>
                                        <br>
                                        <?php if(Auth::user()->role_id == 3): ?>
                                        <form action="<?php echo e(route('loket.hapusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php elseif(Auth::user()->role_id == 5): ?>
                                        <form action="<?php echo e(route('loketKecamatan.hapusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php elseif(Auth::user()->role_id == 7): ?>
                                        <form action="<?php echo e(route('upt.hapusLoket')); ?>" method="post" class="form-horizontal">
                                        <?php endif; ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($row->id); ?>" name="idLoket">
                                            <button type="submit" class="btn btn-rounded btn-danger">Stop Antrian</button>
                                        </form>
                                        
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                    </table>
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    
    <!-- /.row -->

   
</section>

<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('/js/jquery-2.2.4.min.js')); ?>"></script>
<script src="https://code.responsivevoice.org/responsivevoice.js?key=SmCCuXXD"></script>
<script type="text/javascript">
    $(document).ready(function(){
        // code to read selected table row cell data (values).
        $(".btnSelect").click(function () {
            // get the current row
            var currentRow=$(this).closest("tr"); 
            
            var col1=currentRow.find("td:eq(0)").text(); // get current row 1st TD value
            var col2=currentRow.find("td:eq(1)").text(); // get current row 2nd TD
            var col3=currentRow.find("td:eq(2)").text(); // get current row 3rd TD
            var col4=currentRow.find("td:eq(4)").text(); // get current row 3rd TD
            // var lok = $("#naLok").val();
            var data=col1+"\n"+col2+"\n"+col3;
            
            // alert(data);

            responsiveVoice.speak(
                "Nomor Antrian '" + col3 + "' Atas Nama '" + col1 + "' Ke Loket '" + col4 + "'",
                "Indonesian Female",
                {
                pitch: 1, 
                rate: 0.9, 
                volume: 4
                }
            );
        });
    });
  
 </script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/antrian/index.blade.php ENDPATH**/ ?>