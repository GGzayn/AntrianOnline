


<style> 
    section {
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    }
</style>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1 class="box-title">
        Antrian
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Table Antrian</a></li>
    </ol>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
            <div class="box-header">
                <h1 class="box-title">
                    Table Antrian per Loket
                </h1>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Nama Petugas</th>
                                <th>Nama Loket</th>
                                <th>Antrian Hari Ini</th>
                                <th>Status Loket</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($row->nama_petugas); ?></td>
                                <td><?php echo e($row->nama_loket); ?></td>
                                <td><b><?php echo e($row->count_of_today); ?></b></td>
                                <td>
                                    <?php if( $row->status_loket == 1 ): ?>
                                        <b style = "color : green ">ONLINE</b>
                                    <?php elseif($row->status_loket == 0 ): ?>
                                        <b style = "color : red">OFFLINE</b>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-default dropdown-toggle"
                                            data-toggle="dropdown">
                                            <span class="caret"></span>
                                            <span class="sr-only">Toggle Dropdown</span>
                                        </button>
                                        <ul class="dropdown-menu" role="menu">
                                            <form action="<?php echo e(route('dinas.lokets.edit', $row->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('GET'); ?>
                                                <button type="submit" class="btn btn-info btn-rounded">EDIT</button>
                                            </form>
                                            <form action="<?php echo e(route('dinas.lokets.destroy', $row->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-rounded">Delete</button>
                                            </form>

                                        </ul>
                                    </div>
                                    <hr>
                                        <?php if($row->count_of_today != 0): ?>
                                            <form action="<?php echo e(route('loket.statusLoket')); ?>" method="post" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($row->id); ?>" name="idLoket">
                                                <button type="submit" class="btn btn-rounded btn-success">Mulai Antrian</button>
                                            </form>
                                        <?php endif; ?>
                                            <br>
                                            <form action="<?php echo e(route('loket.hapusLoket')); ?>" method="post" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($row->id); ?>" name="idLoket">
                                                <button type="submit" class="btn btn-rounded btn-danger">Stop Antrian</button>
                                            </form>
                                        
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                    </table>
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <div class="row">
        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12">
            <div class="box">
               
                <div class="box-header">
                    <h1 class="box-title">
                        <?php if($row->loket_antrian == 1): ?>
                        <?php echo e($row->layanan->nama_layanan); ?> / Antrian ONLINE
                        <?php else: ?>
                        <?php echo e($row->layanan->nama_layanan); ?> / Antrian Offline
                        <?php endif; ?>
                    </h1>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>
                <!-- /.box-header -->
                <input type="hidden" value="<?php echo e($row->nama_loket); ?>" name="naLok" id="naLok">
                <div class="box-body">
                    <table id="myTable" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Nama </th>
                                <th>NIK</th>
                                <th>Nomor Antrian</th>
                                <th>Tanggal Antrian</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $row->antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ska): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($ska->status_antrian == 1 && $ska->tanggal_antrian == date('Y-m-d') ): ?>
                                    <tr>
                                        <td><?php echo e($ska->nama); ?></td>
                                        <td><?php echo e($ska->nik); ?></td>
                                        <td><?php echo e($ska->no_antrian); ?></td>
                                        <td><?php echo e($ska->tanggal_antrian); ?></td>
                                        <td><b style = "color : red ">Mengantri</b></td>
                                        <td>
                                            <button class=" btn btnSelect"><i class="fa fa-microphone"></i></button>
                                            <form action="<?php echo e(route('loket.statusAntrian')); ?>" method="post" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($ska->id); ?>" name="idAntrian">
                                                <button type="submit" class="btn btn-rounded btn-info">Panggil</button>
                                                
                                            </form>
                                            <br>
                                            <form action="#" method="post" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($ska->id); ?>" name="idAntrian">
                                                <button type="submit" class="btn btn-rounded btn-danger">Selesai</button>
                                            </form>
                                            <br>
                                            
                                        </td>
                                        
                                    </tr>

                                <?php elseif($ska->status_antrian == 2 && $ska->tanggal_antrian == date('Y-m-d') ): ?>
                                    <tr>
                                        <td><?php echo e($ska->nama); ?></td>
                                        <td><?php echo e($ska->nik); ?></td>
                                        <td><?php echo e($ska->no_antrian); ?></td>
                                        <td><?php echo e($ska->tanggal_antrian); ?></td>
                                        <td><b style = "color : green ">Di Loket</b></td>
                                        <td>
                                            <button class=" btn btnSelect"><i class="fa fa-microphone"></i></button>
                                            <form action="<?php echo e(route('loket.hapusAntrian')); ?>" method="post" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($ska->id); ?>" name="idAntrian">
                                                <button type="submit" class="btn btn-rounded btn-danger">Selesai</button>
                                            </form>
                                            <br>
                                        </td>
                                        
                                    </tr>
                                
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                    </table>
                </div>
                <!-- /.box-body -->
                
            </div>
            <!-- /.box -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- /.col -->
    </div>
    <!-- /.row -->

   
</section>

<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('/js/jquery-2.2.4.min.js')); ?>"></script>
<script src="https://code.responsivevoice.org/responsivevoice.js?key=SmCCuXXD"></script>
<script type="text/javascript">
    $(document).ready(function(){
        // code to read selected table row cell data (values).
        $(".btnSelect").click(function () {
            // get the current row
            var currentRow=$(this).closest("tr"); 
            
            var col1=currentRow.find("td:eq(0)").text(); // get current row 1st TD value
            var col2=currentRow.find("td:eq(1)").text(); // get current row 2nd TD
            var col3=currentRow.find("td:eq(2)").text(); // get current row 3rd TD
            var lok = $("#naLok").val();
            var data=col1+"\n"+col2+"\n"+col3;
            
            // alert(data);

            responsiveVoice.speak(
                "Nomor Antrian '" + col3 + "' Atas Nama '" + col1 + "' Ke Loket '" + lok + "'",
                "Indonesian Male",
                {
                pitch: 1, 
                rate: 0.9, 
                volume: 4
                }
            );
        });
    });
  
 </script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/antrian/index.blade.php ENDPATH**/ ?>