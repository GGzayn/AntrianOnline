

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Tabel Berkas Tercetak
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Table Berkas Tercetak</a></li>
    </ol>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                <h3 class="box-title">Table Berkas Pengguna Tercetak </h3>
                <br>
                <h3 class="box-title">Total Berkas yang Harus Dikirim Ke Kelurahan : <?php echo e($newBerkas); ?> </h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIK</th>
                        <th>Status Berkas</th>
                        <th>Status Pengiriman</th>
                        <th>Tanggal/Waktu</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->antrian['nama']); ?></td>
                            <td><?php echo e($row->antrian['nik']); ?></td>
                            <?php if($row->status_berkas == 1): ?>
                                <td> <b style = "color : green "> Berkas Di Terima </b></td>
                            <?php endif; ?>
                            <?php if($row->status_pengiriman == 1): ?>
                                <td><b style = "color : green ">Berkas Telah Dicetak dan Dikirim ke Kecamatan/UPT </b></td>
                            <?php endif; ?>
                            <td><?php echo e($row->updated_at); ?></td>
                            <td>
                                <?php if(Auth::user()->role_id == 4): ?>
                                <form action="<?php echo e(route('kecamatan.berkasKelurahan')); ?>" method="post">
                                <?php elseif(Auth::user()->role_id == 8): ?>
                                <form action="<?php echo e(route('adminUpt.berkasKelurahan')); ?>" method="post">
                                <?php endif; ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($row->id); ?>" name="idBerkas">
                                    <button type="submit" class="btn btn-success btn-rounded">Kirim ke Kelurahan</button>
                                </form>
                            </td>
                        </tr>  
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnlineQueue\resources\views/berkasTercetak.blade.php ENDPATH**/ ?>