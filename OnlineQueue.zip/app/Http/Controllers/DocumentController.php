<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

use App\Models\UserDocuments;
use App\Models\NotifDocuments;
Use App\Models\Antrian;
Use App\Models\Loket;
Use App\Models\Districts;
Use App\Models\Urbans;
use Carbon\Carbon;


class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = auth()->user()->role->id;
        if ($role == 2 ) {
            $data = UserDocuments::where('status_berkas',1)->where('status_pengiriman',0)->with('antrian')->orderBy('id','DESC')->get();
            // $newBerkas = UserDocuments::Where('status_pengiriman',0)->where('status_berkas',1)->count();
            $newBerkas = Loket::where('child_id',auth()->user()->child_id)->whereHas('antrian', function($q)
                {
                    $q->where('status_antrian', '=', 3)->whereHas('userDoc',function($e)
                    {
                        $e->where('status_berkas','=', 1)->where('status_pengiriman','=',0);
                    });
                })->count();
            return view('opd_berkas.index',compact('data','newBerkas'));
        }
        elseif($role == 4 || $role == 8)
        {
            $data = Loket::where('child_id',auth()->user()->child_id)->with('antrian.userDoc')->orderBy('id','DESC')->get();
            // $newBerkas = UserDocuments::Where('status_berkas',0)->count();
            $newBerkas = Loket::where('child_id',auth()->user()->child_id)->whereHas('antrian', function($q)
                {
                    $q->where('status_antrian', '=', 3)->whereHas('userDoc',function($e)
                    {
                        $e->where('status_berkas','=', 0);
                    });
                })->count();
            return view('kec_berkas.index',compact('data','newBerkas'));
        }
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = UserDocuments::where('id',$id)->get();
        return view ('kec_berkas.edit',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $doc = UserDocuments::find($id);

        $doc->status_berkas = $request->status_berkas;
        $doc->note = $request->note;
        $doc->status_baca = false;
        $doc->save();

        $not = new NotifDocuments;
        $not->antrian_id = $doc->antrian_id;
        $not->status_berkas = $request->status_berkas;
        $not->note = $request->note;
        $not->status_baca = false;
        $not->status_pengiriman = $doc->status_pengiriman;
        $not->save();

        $role = auth()->user()->role->id;
        if ($role == 2) 
        {
            return redirect()->route('dinas.documents.index')->with('status','Berkas Telah DiPerbarui');
        }
        elseif($role == 4)
        {
            return redirect()->route('kecamatan.documents.index')->with('status','Berkas Telah DiPerbarui');
        }
        elseif($role == 7)
        {
            return redirect()->route('upt.documents.index')->with('status','Berkas Telah DiPerbarui');
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function get_berkas($id)
    {
        $doc = Antrian::with('notifDoc')->where('id', $id)->get();

        foreach($doc as $row)
        {
            $docs = $row;
        }

        return Response([
            'status' => 'success',
            'message' => 'Pengambilan data berhasil',
            'data' => $docs
        ], 200);
    }

    public function post_berkas(Request $request)
    {
        $doc = NotifDocuments::find($request->id);
        $doc->status_baca = true;
        $doc->save();

        return Response([
            'status' => 'success',
        ], 200);
    }

    public function berkas_kirim(Request $request)
    {
        $data = UserDocuments::find($request->idBerkas);
        $data->status_pengiriman = 1;
        $data->save();

        $not = new NotifDocuments;
        $not->antrian_id = $data->antrian_id;
        $not->status_berkas = $data->status_berkas;
        $not->note = $request->note;
        $not->status_baca = false;
        $not->status_pengiriman = $data->status_pengiriman;
        $not->save();

        return redirect()->route('dinas.documents.index')->with('status','Berkas Telah DiPerbarui');
    }

    public function report_v()
    {
        return view('laporan.index');
    }


    public function report(Request $request)
    {
        
        $exp = explode(' - ',$request->reservation);
        $start = $exp[0];
        $end = $exp[1];
        $doc = UserDocuments::where('status_berkas',1)->whereBetween('created_at', [$start, $end])->with('antrian')->get();
        return view('laporan.data',compact('doc'));
    }

    public function g_berkas()
    {
        $doc = UserDocuments::where('status_pengiriman',2)->orWhere('status_pengiriman',1)->with('antrian')->get();
        return Response([
            'status' => true,
            'message' => 'Pengambilan data berhasil',
            'data' => $doc,
        ], 200);
    }

    public function status_kirim(Request $request, $id)
    {
        $doc = UserDocuments::where('antrian_id',$id)->first();
        $doc->status_pengiriman = $request->status_pengiriman;
        $doc->save();

        $not = new NotifDocuments;
        $not->antrian_id = $doc->antrian_id;
        $not->status_berkas = $doc->status_berkas;
        $not->note = $request->note;
        $not->status_baca = false;
        $not->status_pengiriman = $doc->status_pengiriman;
        $not->save();


        return Response([
            'status' => true,
            'message' => 'Status Pengiriman Berhasil Dirubah',
            'data' => $doc,
        ], 200);

    }

    public function c_berkas()
    {
        // $data = Loket::where('child_id',auth()->user()->child_id)->with('antrian.userDoc')->get();
        $data = UserDocuments::where('status_berkas',1)->where('status_pengiriman',1)->with('antrian.loket')->get();
        $newBerkas = UserDocuments::Where('status_pengiriman',1)->count();
        return view('berkasTercetak',compact('data','newBerkas'));
    }

    public function ck_berkas(Request $request)
    {
        $doc = UserDocuments::find($request->idBerkas);
        $doc->status_pengiriman = 2;
        $doc->save();

        $not = new NotifDocuments;
        $not->antrian_id = $doc->antrian_id;
        $not->status_berkas = $doc->status_berkas;
        $not->note = $request->note;
        $not->status_baca = false;
        $not->status_pengiriman = $doc->status_pengiriman;
        $not->save();

        $role = auth()->user()->role->id;
        if ($role == 4)
        {
            return redirect()->route('kecamatan.berkasTercetak')->with('status','Berkas Telah DiPerbarui');
        }
        elseif($role == 8)
        {
            return redirect()->route('adminUpt.berkasTercetak')->with('status','Berkas Telah DiPerbarui');
        }

        
    }

    public function kelurahan_berkas()
    {   
        $kec = Urbans::where('id',auth()->user()->child_id)->pluck('district_id');
        $data = Loket::where('child_id',$kec[0])->with('antrian.userDoc')->get();
        $newBerkas = UserDocuments::Where('status_pengiriman',2)->count();
        return view('kel_berkas',compact('data','newBerkas'));
    }

    public function kk_berkas(Request $request)
    {
        $doc = UserDocuments::find($request->idBerkas);
        $doc->status_pengiriman = 3;
        $doc->save();

        $not = new NotifDocuments;
        $not->antrian_id = $doc->antrian_id;
        $not->status_berkas = $doc->status_berkas;
        $not->note = $request->note;
        $not->status_baca = false;
        $not->status_pengiriman = $doc->status_pengiriman;
        $not->save();

        return redirect()->route('kelurahan.kelurahanBerkas')->with('status','Berkas Telah DiPerbarui');
    }
    
}
